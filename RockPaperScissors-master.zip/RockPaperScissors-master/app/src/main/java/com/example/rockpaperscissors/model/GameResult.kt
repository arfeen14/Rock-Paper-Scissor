package com.example.rockpaperscissors.model

enum class GameResult(var result: String) {
    Draw("Draw"), Win("You Win!"), Lose("You Lose!")
}